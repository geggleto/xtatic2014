<?php
$id = $_GET['id'];

if (is_numeric($id))
{
    include "lib/db.php";
    $db = new DB();
    $pdo = $db->link;

    //GET MODEL INFO
    $query = "
SELECT 
  city_lkm,
  highway_lkm,
  city_mg,
  highway_mg,
  fuel_year,
  co_emissions 
FROM
  db 
WHERE id = '$id' ;      
";
    
    $stmt = $pdo->prepare($query); 
    $stmt->execute();
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) { 
            print implode(",", $row);
            print "\n";
    }
}
