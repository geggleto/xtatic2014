<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class DB
{
    var $link;
    function __construct() {
        $dsn = 'mysql:host=localhost;dbname=code';
        $username = 'root';
        $password = 'Miller00';
        $options = array(
            PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
        ); 

        $this->link  = new PDO($dsn, $username, $password, $options);
    }
}

?>