<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
include "lib/db.php";
$db = new DB();
$pdo = $db->link;

//List Models
$query = "SELECT 
    DISTINCT
name 
FROM
gasprice";

$stmt = $pdo->prepare($query); 
$stmt->execute();
while($row = $stmt->fetch(PDO::FETCH_ASSOC))
{ 
    print implode(",", $row);
    print "\n";
}