<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$location = mysql_escape_string($_GET['city']);
$year = mysql_escape_string($_GET['year']);

include "lib/db.php";
    $db = new DB();
    $pdo = $db->link;

    //List Models
    $query = "SELECT 
price 
FROM
  gasprice
WHERE year = '".$year."' AND name = '$location';";

    $stmt = $pdo->prepare($query); 
    $stmt->execute();
    while($row = $stmt->fetch(PDO::FETCH_ASSOC))
    { 
        print implode(",", $row);
        print "\n";
    }
