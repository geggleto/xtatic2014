<?php
$year = mysql_escape_string($_GET['year']);

$class = mysql_escape_string($_GET['class']);

$model = mysql_escape_string($_GET['model']);

$manu = mysql_escape_string($_GET['manufacturer']);

$type = mysql_escape_string($_GET['type']);

$cyl = mysql_escape_string($_GET['cylinders']);

$year_s = mysql_escape_string($_GET['start_year']);
$year_e = mysql_escape_string($_GET['end_year']);

$engine = mysql_escape_string($_GET['engine']);

$clause = " 1=1 ";

if (!empty($year))
{
    $clause .= " AND year = '$year'";
}

if (!empty($class))
{
    $clause .= " AND class = '$class'";
}

if (!empty($engine))
{
    $clause .= " AND engine_size $engine";
}

if (!empty($model))
{
    $clause .= " AND model = '$model'";
}

if (!empty($manu))
{
    $clause .= " AND manufacturer = '$manu'";
}

if (!empty($type))
{
    $clause .= " AND fuel_type = '$type'";
}

if (!empty($cyl))
{
    $clause .= " AND cylinders = '$cyl'";
}

if (!empty($year_s) && !empty($year_e))
{
    $clause .= " AND year >= $year_s AND year <= $year_e ";
}

include "lib/db.php";
$db = new DB();
$pdo = $db->link;

//List Models
$query = "SELECT 
id,
year,
manufacturer,
model,
class,
engine_size,
cylinders,
transmission,
fuel_type,
co_emissions,
  city_lkm,
  highway_lkm,
  city_mg,
  highway_mg
FROM
db 
WHERE $clause ";

$stmt = $pdo->prepare($query); 
$stmt->execute();
while($row = $stmt->fetch(PDO::FETCH_ASSOC)) { 
        print implode(",", $row);
        print "\n";
}
