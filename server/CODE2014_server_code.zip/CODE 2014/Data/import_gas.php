<?php
include "../lib/db.php";

$db = new DB();

$x = "econ154a-eng.csv";
$fh = fopen($x, "r");
$contents = explode("\n", fread($fh, filesize($x)));
fclose($fh);
    
for ($r=1; $r<count($contents); $r++)
{
    $data = explode(",", $contents[$r]);
    $city = $data[0];
    $query = "INSERT INTO gasprice (`name`, `year`, `price` ) VALUES ('".mysql_escape_string($city)."', '2010', '".$data[1]."');";
    print $query;
    $db->link->exec($query);
    
    $query = "INSERT INTO gasprice (`name`, `year`, `price` ) VALUES ('".mysql_escape_string($city)."', '2011', '".$data[2]."');";
    $db->link->exec($query);
    
    $query = "INSERT INTO gasprice (`name`, `year`, `price` ) VALUES ('".mysql_escape_string($city)."', '2012', '".$data[3]."');";      
    $db->link->exec($query);
    
    $query = "INSERT INTO gasprice (`name`, `year`, `price` ) VALUES ('".mysql_escape_string($city)."', '2013', '".$data[4]."');";      
    $db->link->exec($query);
    
    $query = "INSERT INTO gasprice (`name`, `year`, `price` ) VALUES ('".mysql_escape_string($city)."', '2014', '".$data[5]."');";      
    $db->link->exec($query);
}

