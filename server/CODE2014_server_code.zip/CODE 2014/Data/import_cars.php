<?php
include "../lib/db.php";

$db = new DB();

for ($x=2002; $x<2014; $x++)
{
    $fh = fopen($x, "r");
    $contents = explode("\n", fread($fh, filesize($x)));
    fclose($fh);
    
    for ($r=2; $r<count($contents); $r++)
    {
        $data = explode(",", $contents[$r]);
        //$data[0] = $data[0]."/01/01";
        $query = "
INSERT INTO db
(`year`, `manufacturer`, `model`, `class`, `engine_size`, `cylinders`, `transmission`, `fuel_type`, `city_lkm`, `highway_lkm`, `city_mg`, `highway_mg`, `fuel_year`, `co_emissions`)
VALUES('".implode("','", $data)."')
";
        $db->link->exec($query);
    }
}
