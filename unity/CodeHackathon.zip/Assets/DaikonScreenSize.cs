﻿using UnityEngine;
using System.Collections;

[ExecuteInEditMode]
public class DaikonScreenSize : MonoBehaviour {

	Vector2 prevScreenSize;

	void Update(){

		Vector2 newScreenSize = new Vector2(Screen.width, Screen.height);

		if (prevScreenSize != newScreenSize){
			var dfgm = GetComponent<dfGUIManager>();
			dfgm.FixedHeight = Screen.height;
			dfgm.FixedWidth = Screen.width;
		}

	}
}
