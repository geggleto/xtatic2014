﻿using UnityEngine;
using System.Collections;
using System;

public class DataManager : MonoBehaviour {

	string carmodels;

	string yearInput;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnGUI(){

		if (GUILayout.Button("get car 2013")){
			StartCoroutine(GetModels(2013));
		}
	}

	IEnumerator GetModels(int year)
	{

		string url = "http://107.170.58.57/ListModels.php?year=2013";

		WWW www = new WWW (url);



		while (!www.isDone){
			yield return null;
		}

		print (www.bytesDownloaded);

		print (www.error);

		print (www.text);

	}
}

class Car{


}